## Description ##

Orglendar is a calendar/organizer widget for Awesome. It parses Emacs org-mode files and show the scheduled and deadline dates on the calendar.

See more information and installation guide here: http://awesome.naquadah.org/wiki/Orglendar_widget

## Version ##

This version is intended for the git/master version of Awesome. If you use Awesome v.3.4.X please use this version: https://github.com/alexander-yakushev/Orglendar/tree/awesome-3.4.x .