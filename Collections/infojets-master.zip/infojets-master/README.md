## Description ##

Infojets is the set of widgets for Awesome WM to be used in the on-screen wiboxes. 
taskbar background and on-screen widgets. It includes:

* Log watcher widget
* Process watcher widget
* Clock widget

## Dependencies ##

Conscience depends on the following projects:

* [awesome pre-3.5](http://git.naquadah.org/awesome.git)
* [asyncshell](https://gist.github.com/1466863)

## Instalation ##

Place all files in the ~/.config/awesome/infojets/ folder. Then add
this line to the rc.lua file:

     infojets = require("infojets")

